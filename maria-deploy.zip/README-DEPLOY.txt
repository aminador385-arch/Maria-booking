MARIA — نشر على Render (خطوات سريعة)
====================================

الملفات في هذا المجلد هي كل المنصة:
  server/      الخادم + الصفحات (dashboard, join, partner, request, pay)
  book/        صفحة البحث والحجز
  render.yaml  إعدادات النشر التلقائي على Render

كيف تنشر:
1. github.com → New repository → اسمه maria-booking → Create
2. في الصفحة الفارغة: "uploading an existing file"
3. اسحب المجلدات الثلاثة (server, book) + ملف render.yaml دفعة واحدة
4. Commit changes
5. render.com → New → Blueprint → اختر المستودع → Apply
6. انتظر 3–5 دقائق → افتح الرابط

قاعدة البيانات (مهمة لبقاء البيانات):
- Render المجاني يمسح الملفات عند كل إعادة تشغيل
- الحل: neon.tech (مجاني) → انسخ Connection string
- في Render: Environment → DATABASE_URL → ألصق الرابط → Save
